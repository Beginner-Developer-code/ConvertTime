let inputr = document.getElementById("binary");
let inputd = document.getElementById("decimal");
let p = document.getElementById("msg");

function dec_bin(num) {
  binary = "";

  while (num != 0) {
    r = num % 2;
    num = (num - r) / 2;
    binary = r + binary;
  }

  return binary;
}

function wConvert() {
  n = document.getElementById("decimal").value;

  if (isNaN(n)) {
    p.innerHTML = "Inserisci solo i numeri!!!";
    inputd.value = "";
  } else if (n < 0) {
    p.innerHTML = "Inserisci numeri sopra lo zero!!!";
    inputd.value = "";
  } else {
    p.innerHTML = "";
    result = dec_bin(n);
    inputr.value = result;
  }
}

function Clear() {
  inputr.value = "";
  inputd.value = "";
}
